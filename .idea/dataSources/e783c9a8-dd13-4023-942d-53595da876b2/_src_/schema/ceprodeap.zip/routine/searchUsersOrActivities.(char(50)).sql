CREATE PROCEDURE `searchUsersOrActivities`(`dataIn` CHAR(50))
  BEGIN
	SET @dataIn  =CONCAT('%', dataIn,'%');

	SELECT DISTINCT usuarios.* FROM usuarios 
WHERE usuarios.nombre LIKE @dataIn OR 
	usuarios.apellido LIKE @dataIn OR 
    usuarios.cedula LIKE @dataIn 
    UNION 
		SELECT DISTINCT usuarios.* FROM usuarios, actividades, usuario_has_actividad
            WHERE (usuario_has_actividad.id_usuario=usuarios.id AND
                usuario_has_actividad.id_actividad=actividades.id) AND
                actividades.numero_actividad LIKE @dataIn;
END